function [dx, y] = SDOF(t,x,u,... ,varargin)
% x(1) = angular position
% x(2) = angular velocity
g = 9.81;

dx = ;
y = ;

end