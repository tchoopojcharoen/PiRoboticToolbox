function [dx, y] = SDOF(t,x,u,m,l,b,varargin)
% x(1) = angular position
% x(2) = angular velocity
g = 9.81;

dx = [ x(2);(-m*g*l*sin(x(1))-b*x(2)+u)/(m*l^2)];

y = x;

end