% Fixed parameters for Input excitation
A = 15;
f_in = 0.125;
std_1 = sqrt(0.01);
std_2 = sqrt(0.02);

m_est = 2;
l_est = 1;
b_est = 0.25;

m = m_est+0.2*(rand-0.5);
l = l_est+0.02*(rand-0.5);
b = b_est+0.02*(rand-0.5);
g = 9.81;
p_actual = [m l b];

t_f = 10;
sim('SDOFModel');


t = y_sim.Time;
y = y_sim.Data;
u = u_sim.Data;

save('logged_data_SDOF.mat','t','y','u','t_f','A','f_in','p_actual')
