A = 15;
f_in = 0.125;
std_1 = sqrt(1);
std_2 = sqrt(1);

r =  40;
tau_est = 2;
k_est = 1;

tau = tau_est+0.2*(rand-0.5);
k = k_est+0.02*(rand-0.5);
p_actual = [tau k ];

t_f = 10;
sim('DCMotorModel');


t = y_sim.Time;
y = y_sim.Data;
u = u_sim.Data;

save('logged_data_DC.mat','t','y','u','t_f','A','f_in','p_actual')