function [dx, y] = DCMotor(t,x,u,tau,k,varargin)
% x(1) = angular position
% x(2) = angular velocity

% J_m = J_a + J_g
% J/B >> L/R

% k = K_m/(R*B);
% tau = (J_m*r^2)/(B_m*r^2+K_m*K_b/R);

% tau = time-constant
% k = static gain

dx = [ x(2);-(1/tau)*x(2)+(k/tau)*u];

y = x;

end

