%% Obtaining Logged Data

% For practical application, you have to load logged data from external
% file. Normally, logged data is saved as csv file.

% For this class, we simulated physical system using Simulink.

% simulate_real_SDOF
load('logged_data_SDOF.mat');

figure(1)
n_y = size(y,2);
for i = 1:n_y
subplot(n_y,1,i);
hold on;
plot(t,y(:,i),'x');
xlabel('t');
str = sprintf('y_%d',i);
ylabel(str);
grid on;
end

data_name =  ; % change the data name as you prefer
z = iddata(y, u, 0.1, 'Name', data_name);

%% Seting up Nonlinear Greybox Model

FileName      = ;       % File describing the model structure.
n_y = ;
n_u = ;
n_x = ;
n_p = ;
Order         = [n_y n_u n_x];     % Model orders [ny nu nx].

% determine how many parameters are in the system
m_est = ;
...
    
Parameters    = [m_est; ...];         % Initial parameters. Np = ?.
InitialStates = ;            % Initial initial states.
Ts            = 0;                 % Time-continuous system.
nlgr = idnlgrey(FileName, Order, Parameters, InitialStates, Ts, ...
                'Name', 'SDOF');

% not important (line 63-75)
set(nlgr, 'InputName', 'Torque', 'InputUnit', 'N-m',               ...
          'OutputName', {'Angular position', 'Angular velocity'}, ...
          'OutputUnit', {'rad', 'rad/s'},                         ...
          'TimeUnit', 's');
      
nlgr = setinit(nlgr, 'Name', {'Angular position' 'Angular velocity'});
nlgr = setinit(nlgr, 'Unit', {'rad' 'rad/s'});


nlgr = setpar(nlgr, 'Name', {'Mass' 'Center of Mass' 'Damping'});
nlgr = setpar(nlgr, 'Unit', {'kg' 'm' 'kg-m/s'});
%

opt = nlgreyestOptions('Display','on');
opt.SearchOption.MaxIter = 100;

%% Estimating Parameters 

tic;
nlgr = nlgreyest(z, nlgr, opt);
toc

p_est = zeros(1,n_p);
for i = 1:n_p
    p_est(i) = nlgr.Parameter(i).Value;
end

%% Verifying the model

% simulate the model using ode45

u = @(t)A*sin(2*pi*f_in*t); % you can use other excitations as well
[t_est,x_est] = ode45(???,t,InitialStates);
y_est = zeros(size(x_est,1),n_y);
for i = 1:size(x_est,1)
    [~,y_temp] = ???;
    y_est(i,:) = y_temp;
end

for i = 1:n_y
subplot(n_y,1,i)
plot(t_est,x_est(:,i));
    
end
